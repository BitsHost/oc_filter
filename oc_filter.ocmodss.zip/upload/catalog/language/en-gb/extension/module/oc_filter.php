<?php
// Heading
$_['heading_title'] = 'Filter Products';

// Text
$_['text_price']       = 'Price';
$_['text_brand']       = 'Brand';
$_['text_metakeywords'] = 'Keywords';
$_['text_filter']      = 'Filter';
$_['text_clear']       = 'Clear Filters';